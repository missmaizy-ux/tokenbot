export declare namespace Util {
  export interface Dictionary { [k: string]: string }
}