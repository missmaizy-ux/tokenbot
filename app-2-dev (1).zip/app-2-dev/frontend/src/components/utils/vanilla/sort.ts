export const byAscending = (key: string) => (a, b) => (a[key] > b[key]) ? 1 : -1;
