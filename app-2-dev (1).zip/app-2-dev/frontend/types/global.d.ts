declare global {
  const events: EventEmitter;
}
export {};